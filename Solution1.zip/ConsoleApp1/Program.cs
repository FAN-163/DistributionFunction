﻿
using System;

using System.Text.RegularExpressions;

namespace ConsoleApp1
{
    class Program
    {
        
        static double summ = 10000;
        static public string amounts = "1000;2000;3000;5000;8000;5000";
        static public Regex regex = new Regex(@"\d+");

        //List<T>  ; 
        static void Main(string[] args)
        {

            Distribute dist = new Distribute(summ, amounts, regex);
            while (true)
            {
                Console.Clear();


                Console.WriteLine("Способы распределения распределения");
                Console.WriteLine("1 - ПРОП \n2 - ПЕРВ \n3 - ПОСЛ \n4 - ... ");
                Console.WriteLine("Введите номер пункта меню");

                int numberMenu = int.Parse(Console.ReadLine());


                /*  if (numberMenu != regex)
                  {
                      Console.WriteLine("Недопустимые символы, введите от 1 до 4");
                      break;
                  }
                  else
                  {*/
                //Convert.ToInt16(numberMenu);

                switch (numberMenu)
                {

                    case (1):
                        
                        dist.Apportionment();
                        Console.WriteLine(dist);
                        Console.ReadKey();
                        break;
                    case (2):
                        
                        dist.First();
                        Console.WriteLine(dist);
                        Console.ReadKey();
                        break;
                    case (3):
                        dist.Last();
                        Console.WriteLine(dist);
                        Console.ReadKey();
                        break;
                  
                }
                Console.ReadKey();
            }

        }
    }
}
    


